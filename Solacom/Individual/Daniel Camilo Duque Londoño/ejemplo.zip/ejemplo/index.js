// conexion a BD
const express = require('express');
const mongoose = require('mongoose');

const app = express();
const PORT = 3000;

// crear el cuerpo de las peticiones a hacer (Middleware)

app.use(express.json());

// conexión BD

mongoose.connect("mongodb://localhost:27017/BDMongo",{
    useNewURLParser : true,
    useUnifiedTopology: true
}).then(() => console.log('Se conectó a Mongo')) 
.catch(err=> console.error('No se conectó a BD',err));

// Iniciar el servidor

app.listen(PORT,()=>{console.log('servidor ejecutandose sobre el puerto:,${PORT}')});