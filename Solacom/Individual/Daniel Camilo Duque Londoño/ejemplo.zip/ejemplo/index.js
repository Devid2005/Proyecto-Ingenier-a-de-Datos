// conexion a BD
const express = require('express');
const mongoose = require('mongoose');

const app = express();
const PORT = 3000;

// crear el cuerpo de las peticiones a hacer (Middleware)

app.use(express.json());

// conexión BD

mongoose.connect("mongodb://localhost:27017/BDMongo",{
    useNewURLParser : true,
    useUnifiedTopology: true
}).then(() => console.log('Se conectó a Mongo')) 
.catch(err=> console.error('No se conectó a BD',err));

// Iniciar el servidor

app.listen(PORT,()=>{console.log('servidor ejecutandose sobre el puerto:,${PORT}')});

// ageragar las rutas para manipular user

const User = require('./user');

// Registrar un usuario nuevo

app.post('/users',async(req,res) => {
    try{
        const user = new user (req.body);
        await user.save();
        res.status(200).sendStatus(user);
    }catch(error){
        res.status(400).send(error);
    }
});

// consultar usuarios

app.get('/users',async(req,res) => {
    try{
        const users = await users.find();
        res.status(200).sendStatus(users);
    }catch(error){
        res.status(500).send(error);
    }
});

// consultar usuario pór id

app.get('/users/:id',async(req,res) => {
    try{
        const user = await user.findById(req.params.id);
        if(!user) return response.status(404).send();
        res.status(200).sendStatus(user);
    }catch(error){
        res.status(500).send(error);
    }
});

// actualizar un usuario 

app.put('/users/:id',async(req,res) => {
    try{
        const user = await user.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true});
        if(!user) return response.status(404).send();
        res.status(200).sendStatus(user);
    }catch(error){
        res.status(400).send(error);
    }
});

// eliminar usuario por id
app.delete('/users/:id',async(req,res) => {
    try{
        const user = await user.findById(req.params.id);
        if(!user) return response.status(404).send();
        res.status(200).sendStatus(user);
    }catch(error){
        res.status(500).send(error);
    }
});