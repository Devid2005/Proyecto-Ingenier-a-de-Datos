// conexion a BD
const express = require('express');
const mongoose = require('mongoose');

const app = express();
const PORT = 3000;

// Crear el cuerpo de las peticiones (Middleware)
app.use(express.json());

// conexion BD 
mongoose.connect('mongodb://localhost:27017/crud',{
    useNewURLParser: true,
    useUnifiedTopology:true
}).then( ()=> console.log('Se conecto a Mongo'))
.catch(err=>console.error('No se conecto a BD eror:', err));

// Iniciar el servidor
app.listen(PORT,()=>{
    console.log('Servidor ejecutandose sobre el puerto:', PORT);
});

// agregar las rutas para maninpular user

const User = require('./user');
const user = require('./user');

// Registrar un usuario nuevo
app.post('/users', async(req,res)=>{
try{
    const user = new User(req.body);
    await user.save();
    res.status(201).send(user);

}catch(error){
    res.status(400).send(error);
}
})

// consultar 
app.get('/users', async(req,res)=>{
    try{
        const users = await User.find({});
        res.status(201).send(users);
    
    }catch(error){
        res.status(500).send(error);
    }
})

// consultar usuarios por ID
app.get('/users/:id', async(req,res)=>{
    try{
        const user = await User.findById(req.params.id);
        if(!user) return responde.status(404).send()
        res.status(201).send(user);
    
    }catch(error){
        res.status(500).send(error);
    }
})

// actualizar usuarios por ID
app.get('/users/:id', async(req,res)=>{
    try{
        const user = await User.findByIdAndUpdate(req.params.id,req.body,{new:true, runValidators:true});
        if(!user) return responde.status(404).send()
        res.status(201).send(user);
    
    }catch(error){
        res.status(400).send(error);
    }
})

// Eliminar el usuario por ID
app.get('/users/:id', async(req,res)=>{
    try{
        const user = await User.findByIdAndDelete(req.params.id);
        if(!user) return responde.status(404).send()
        res.status(201).send(user);
    
    }catch(error){
        res.status(400).send(error);
    }
})

