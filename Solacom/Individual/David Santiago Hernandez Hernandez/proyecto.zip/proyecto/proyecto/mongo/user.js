// Modelo para definir la manipulacion del modulo de usuarios, permitir manejo de usuarios

const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    nombre:{
        type:String,
        require:true
    },
    edad:{
        type:Number,
        require: true,
    },
    email:{
        type:String,
        require: true
    }
});

module.exports = mongoose.model('user',userSchema);



