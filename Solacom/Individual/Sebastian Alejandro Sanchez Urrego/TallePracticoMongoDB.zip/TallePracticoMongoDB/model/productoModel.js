import mongoose, { Schema } from "mongoose";

const productoSchema = new Schema({
    nombre: String,
    precio: Number,
    categoria: String
})

export const productoModel = new mongoose.model('Productos', productoSchema)