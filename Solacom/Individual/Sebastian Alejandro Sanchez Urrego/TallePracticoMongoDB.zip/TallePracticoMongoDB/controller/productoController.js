import { productoModel } from "../model/productoModel.js";

//consultar datos

export const obtenerDatos = async (peticion, respuesta) => {
    try {
        let productos = await productoModel.find()
        respuesta.status(200).render("index", { productos })
    } catch (error) {
        console.log(error);
    }
}

//registrar datos
export const crearDatos = async (peticion, respuesta) => {
    try {
        let data = peticion.body
        // Guardar datos
        await productoModel.create(data)
        // devuelve la vista al producto para vea los nuevos datos
        let productos = await productoModel.find()
        respuesta.status(200).render("index", { productos })
    } catch (error) {
        console.log(error);
    }
}


// modificar datos

// eliminar datos