import { Router } from "express";
import { crearDatos, obtenerDatos } from "../controller/productoController.js";
const router = Router()

router.get('/producto', obtenerDatos)
router.post('/producto', crearDatos)


export default router;