import { Router } from "express";
import { crearDatos, obtenerDatos, obtenerDatosNombre } from "../controller/userController.js";
const router = Router()

router.get('/usuarios', obtenerDatos)
router.get('/producto', obtenerDatosNombre)
router.post('/usuarios', crearDatos)


export default router;