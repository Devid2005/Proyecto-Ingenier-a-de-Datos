//  Conexion a BD
const express=require('express'); //necesito los modulos para la conexion 
const mongoose=require('mongoose');

const app=express();
const PORT=3000 //localhost

//Crear cuerpo de las peticiones (Middleware)
app.use(express.json()); //la peticion me cree archivos json

//conexion DB

mongoose.connect('mongodb://localhost:27017/BDMongo',{
    useNewURLParser:true,
    useUnifiedTopology:true
}).then(()=> console.log('Se conecto a MongoDB'))
.catch(err=>console.error('No se conecto a BD',err));
 
//Iniciar el servidor 
app.listen(PORT,()=>{
    console.log('Servidor ejecutandose sobre puerto :${PORT}')
});