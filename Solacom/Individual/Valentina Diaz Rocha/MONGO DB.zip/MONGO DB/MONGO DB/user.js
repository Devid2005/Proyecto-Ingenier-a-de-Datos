//mODULO PARA DEFINIR LA MANIPULACION 

const mongoose=require('mongoose');
 //no existen datos auto_increment
const userSchema=new mongoose.Schema({
    nombre:{
        type:String,
        require:true
},
     edad:{
        type:Number,
        require:true
     },
     email:{
    type:String,
    require:true
}

});
//EXPORTO MODULO DE MONGOOSE 
module.exports=mongoose.model('user',userSchema);
