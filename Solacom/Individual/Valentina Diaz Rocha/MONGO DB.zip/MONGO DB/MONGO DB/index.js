//  Conexion a BD
const express=require('express'); //necesito los modulos para la conexion 
const mongoose=require('mongoose');

const app=express();
const PORT=3000 //localhost

//Crear cuerpo de las peticiones (Middleware)
app.use(express.json()); //la peticion me cree archivos json

//conexion DB

mongoose.connect('mongodb://localhost:27017/BDMongo',{
    useNewURLParser:true,
    useUnifiedTopology:true
}).then(()=> console.log('Se conecto a MongoDB'))
.catch(err=>console.error('No se conecto a BD',err));
 
//Iniciar el servidor 
app.listen(PORT,()=>{
    console.log('Servidor ejecutandose sobre puerto :',PORT)
    });

//AGREGAR LAS RUTAS PARA MANIPULAR USER 
const User =require ('./user.js');

//Registrar un usuario nuevo (ruts siempre en minuscula)

app.post('/users', async(req,res)=>{
    try{
        //instancia una clase se crea un objeto
     const user =new User(req.body);
      await user.save();
      res.status(201).send(user) //se realizo exitoso


    }catch(error){ //siempre muestra el error ;
    res.status(400).send(error) //not found
}
})

// Consultar el usuario (as Select *From)
//find all para que muestre todo 

app.get('/users',async(req,res)=>{
    try{
        
     const users= await User.find(); // asignar una consulta 
      res.status(201).send(users) //se realizo exitoso

    }catch(error){ //siempre muestra el error ;
    res.status(400).send(error) //not found
    }

})

//Consultar usuario X id 

app.get('/users/:id',async(req,res)=>{
    try{
        
     const user = await User.findById(req.params.id); // asignar una consulta X id 
     if (!user)return response.status(404).send(error)
      res.status(201).send(users) //se realizo exitoso

    }catch(error){ //siempre muestra el error ;
    res.status(500).send(error) //not found
    }

})

//Actualizar un usuario 

app.get('/users/:id',async(req,res)=>{
    try{
        
     const user = await User.findByIdAndUpdate(req.params.id,req.body,{new:true,runValidators:true}); // COMBINACION ENTRE UN REGISTRO Y UNA CONSULTA x ID 
     if (!user)return response.status(404).send(error)
      res.status(201).send(users) //se realizo exitoso

    }catch(error){ //siempre muestra el error ;
    res.status(400).send(error) //not found
    } 

})

//Eliminar 

app.get('/users/:id',async(req,res)=>{
    try{
        
     const user = await User.findByIdDelete(req.params.id); // COMBINACION ENTRE UN REGISTRO Y UNA CONSULTA x ID para eliminar 
      res.status(201).send(users) //se realizo exitoso

    }catch(error){ //siempre muestra el error ;
    res.status(400).send(error) //not found
    } 

})